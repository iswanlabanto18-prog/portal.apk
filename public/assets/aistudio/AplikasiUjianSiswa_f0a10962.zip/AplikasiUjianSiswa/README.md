# Portal Siswa CBT (Android)

Aplikasi Android dari `aplikasi_client_siswa.html`: Kotlin + WebView, dengan lapisan keamanan native.

## Cara membangun APK
1. Buka folder ini di **Android Studio** (Koala/2024.1+ atau lebih baru, JDK 17), tunggu Gradle sync.
2. Colok perangkat / emulator, tekan **Run**.
3. APK: menu **Build > Build APK(s)** (hasil di `app/build/outputs/apk/`).

## Fitur native
- **Screen pinning** (kunci aplikasi) otomatis saat ujian aktif. Android meminta konfirmasi siswa sekali.
  Untuk kunci penuh tanpa konfirmasi, jadikan aplikasi *Device Owner* (mode kiosk resmi).
- **Anti-screenshot / perekaman layar** (FLAG_SECURE) selama ujian.
- **Volume media dipaksa >= 70%** (benar-benar diatur, bukan sekadar pernyataan).
- Keluar dari aplikasi / kehilangan fokus => pelanggaran, sirine, dan layar kunci (PIN Pengawas).
- Tombol **Back** membuka dialog PIN Keluar selama ujian.
- Izin kamera (pindai QR) & mikrofon diminta saat dibutuhkan; layar tetap menyala.

## Catatan
- Perlu internet (Firestore, Google Form, jsQR & font via CDN).
- Ganti ikon di `app/src/main/res/` bila perlu; ubah `applicationId` di `app/build.gradle.kts` bila perlu.
- Logika ujian ada di `app/src/main/assets/index.html`.
